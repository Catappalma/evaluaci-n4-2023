from Clases.prestamo import Prestamo
from CRUD.crud import *
from CRUD.encrip import encode
from CRUD.json import *
from CONEX.conn import conex
connection = conex()

class Acceso():

    def registroUsuarios(self):
        usuario = input("Ingrese un Usuario : ")
        email = input("Ingrese un Correo : ")
        contraseña = input("Ingrese una contraseña : ")
        print(f"la clave encriptada es {encode(contraseña)}")
        registroUsuarios(usuario, email, encode(contraseña),connection)

class Menu:

    def __init__(self):
        prestamos = []
        #Proceso de mejora: se dividirán en dos menús para un mejor orden y mejor visibilidad para el usuario.
        while True:
            print('')
            print("Opciones de Menú: ")
            print('A.- Menú de libreria.')
            print('B.- Menú de Json.')
            print('C.- Salir.')
            op = input('Ingrese su opción: ')
            print('')
            
            
            if op == 'a' or op == 'A':
                while True:
                    print('')
                    print("\nMENÚ DE LIBRERIA")
                    print('1.- Ingresar libro a la estantería.')
                    print('2.- Mostrar libros de la estanteria.')
                    print('3.- Buscar libros en la estantería.')
                    print('4.- Eliminar un libro de la estantería.') 
                    print('5.- Actualizar un libro de la estantería.')
                    print('6.- Realizar un prestamo.')
                    print('7.- Listar prestamos.')
                    print('8.- Agregar prestamo a la tabla.')
                    print('9.- Mostrar prestamos de la tabla.')
                    print('0.- Salir')

                    opcion = input('\nIngrese su opción: ')
                    print('')
                        

                    if opcion == '1':         
                        print('1.- Ingresará un libro a la estantería')
                        titulo = input('Ingrese el título del libro: ')
                        isbn = input('ingrese el ISBN del libro: ')
                        cat = input('ingrese la categoría del libro: ')
                        nombre_autor = input('ingrese el autor del libro: ')
                        insertarlibro(titulo, isbn, cat, nombre_autor)
                        print('El libro ha sido agregado correctamente.')
                                
                    elif opcion == '2':
                        print('Se mostrarán los libros que hay en la estantería')            
                        selectAll_libreria(connection)
                                    
                    elif opcion == '3':
                            print('Buscar libros en la estantería')
                            busqueda = input("Ingrese el titulo del libro a buscar: ")
                            selectOne_libreria(busqueda, connection)
                                            
                    elif opcion == '4':
                            print("Se eliminará un libro de la estantería.")
                            tit = input("Ingrese el nombre del libro: ")
                            autor = input("Ingrese el autor del libro: ")
                            eliminarlibro(tit, autor)
                                                        
                    elif opcion == '5':                
                        print("Se actualizará un libro de la estanteria.")
                        titulo_libro = input("Ingrese el titulo del libro que desea actualizar: ")
                        selectOne_libreria(titulo_libro, connection)
                        nuevo_titulo = input("Ingrese el nuevo título del libro: ")
                        nueva_categoria = input("Ingrese la nueva categoría del libro: ")
                        nuevo_autor = input("Ingrese el nuevo autor del libro: ")
                        update_libro(titulo_libro, nuevo_titulo, nueva_categoria, nuevo_autor, connection)
                                
                    elif opcion == '6':
                        print('Realizará un prestamo.')
                        ti = input('Ingrese el libro que desea: ')
                        nom = input('Ingrese su nombre: ')
                        prestamo = Prestamo(ti, nom)
                        prestamos.append(prestamo)
                        print('La prestación del libro se ha realizado exitosamente.')
                        
                    elif opcion == '7':
                        print('Se listarán los prestamos.')
                        for p in prestamos:
                                print(p)
                        
                    elif opcion == '8':
                        print('Se agregará el prestamo a la tabla.')
                        insertarPrestamo(ti, nom)  
                        
                    elif opcion == '9':
                        print('Se mostrarán lo prestamos que hay en la tabla.')
                        mostrarPrestamos(connection)
                        
                    elif opcion == '0':
                        print('''\nMuchas gracias por visitar el menú de libreria :)!!''')
                        break
                    else:
                            print('Opción invalida ')

            elif op == 'b' or op == 'B':
                    while True:
                        print('')
                        print("\nMENÚ PRESTAMOS JSON.")
                        print('1.- Leer Archivos de prestamos Json.')
                        print('2.- Importar Json a la BD.')
                        print('3.- Exportar a archivo Json.')
                        print('0.- Salir')

                        opcion = input('\nIngrese una opción: ')
                        if opcion == '1':
                                print('Se Leeran los datos del archivo Json que ya existen.')
                                leerJson()        
                        elif opcion == '2':
                                print('Se importarán los datos desde el archivo Json hacia la Base de datos.')
                                importPrestamoJson()
                        elif opcion == '3':
                                print('Se exportarán los datos al archivo Json.')
                                preparacion_export()
                        elif opcion == '0':
                                print('\nMuchas gracias por haber ingresado al menú de Json :)!!')
                                break
                        else:
                            print('La opción ingresada no es valida.')

            elif op == 'c' or op == 'C':
                print('Hasta pronto!!')
                break

            else:
                print('Error, la opción ingresada no es valida. Por favor intente nuevamente.')
                break 