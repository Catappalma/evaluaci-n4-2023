class Usuario:
    def __init__(self, nombre_usuario, apellido_usuario, id_usuario):
        self.nombre_usuario = nombre_usuario
        self.apellido_usuario = apellido_usuario
        self.id_usuario = id_usuario
    
    def __str__(self):
        return '''
        Nombre del usuario:\t{}
        Apellido del usuario:\t{}
        Id del usuario:\t{}'''.format(self.nombre_usuario,self.apellido_usuario,self.id_usuario)
