from Clases.estanteria import Estanteria
from Clases.prestamo import Prestamo

while True:
    print('---Menú---')
    print(''' 
    1.- Agregar Libro.   
    2.- Eliminar Libro.
    3.- Listar Libros.
    4.- Hacer Prestamos de libros.
    5.- Mostrar Prestamos.
    6.- Salir.
    ''')  
    op = input('Seleccione una opción: ')

    if op == '1':
        print('Ha seleccionado la opción de agregar un libro. ')
        titulo = input('Ingrese el título del libro: ')
        isbn = input('ingrese el ISBN del libro: ')
        cat = input('ingrese la categoría del libro: ')
        nombre = input('ingrese el autor del libro: ')
        libro = Estanteria(titulo, isbn, cat, nombre)
        libro.agregar(libro)
        print('El libro ha sido agregado correctamente.')
    elif op == '2' and op :
        try: 
            print("Ha seleccionado la opción de eliminar un libro. ")
            numLib = int(input('ingrese el número del libro a eliminar: '))
            libro.eliminar(int(numLib))
            print('El libro ha sido eliminado exitosamente.')
        except (ValueError, IndexError):
            print('Error, por favor ingrese un número válido.')
            continue
    elif op == '3':
        print('Ha seleccionado listar libros: ')
        libro.listar()
    elif op == '4':
        print('Ha solicitado hacer un prestamo.')
        titulo_l = input('Ingrese el libro que desea: ')
        nombre_usuario = input('Ingrese su nombre: ')
        #apellido_usuario = input('Ingrese su apellido: ')
        #id_usuario = input('Ingrese su id: ')
        prestamo = Prestamo(titulo_l, nombre_usuario)
        prestamo.agregar_prestamo(prestamo)
        print('La prestación del libro se ha realizado exitosamente.')
    elif op == '5': 
        print('Ha seleccionado la opción mostrar prestamos. ')
        prestamo.listar_prestamos()
    elif op == '6':
        print('¡Muchas gracias por haber ingresado a esta librería :)!')
        break

    else:
        print('!Por favor, ingrese una opción valida!')