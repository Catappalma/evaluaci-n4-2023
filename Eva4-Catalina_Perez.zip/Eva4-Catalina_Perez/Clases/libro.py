from Clases.autor import Autor

class Libro(Autor):
    valoracion_libro = ['Interesante', 'Aburrido']
    
    def __init__(self, titulo, isbn, categoria, nombre_autor):
        self.titulo = titulo
        self.isbn = isbn
        self.categoria = categoria
        super().__init__(nombre_autor)

    