class Prestamo:
    prestamos = []

    def __init__(self, titulo_l, nombre_usuario):
        self.titulo_l = titulo_l
        self.nombre_usuario = nombre_usuario #agregación
        
    def __str__(self):
        return '''
        titulo del libro:\t{}
        nombre del usuario:\t{}'''.format(self.titulo_l, self.nombre_usuario)
    
    def agregar_prestamo(self, libro): #agregacion
        self.prestamos.append(libro)

    def listar_prestamos(self):
            counter = 1
            print('Estos son los prestamos que se han realizado: ')
            for prestamos in self.prestamos:
                 print('\tPrestamo n°: ', counter, prestamos)
                 counter += 1
                 print('---------')
