from Clases.libro import Libro
from Clases.autor import Autor

class Estanteria(Libro, Autor):
    biblioteca = []

    def __str__(self):
        return '''
        Titulo:\t\t{}
        ISBN:\t\t{}
        Categoría:\t{}
        Autor:\t\t{}'''.format(self.titulo, self.isbn, self.categoria, self.nombre_autor)
    
    def agregar(self, libro):
        self.biblioteca.append(libro)

    def listar(self):
        counter = 1
        print('Los libros que hay en la biblioteca son: ')
        for libro in self.biblioteca:
            print('\tLibro n°: \t', counter, libro)
            counter = counter + 1

    def eliminar(self, index):
        self.biblioteca.pop(index-1)
