class Autor:
    edad = []
    direccion = []
    editorial = []
    __rut = 'Soy privado' #atributo privado

    def __init__(self, nombre_autor):
        self.nombre_autor = nombre_autor
    
    def rut_privado(self): #metodo para definir que este atributo es privado
        print(self.__rut)

    def obtener_rut_privado(self): #metodo publico para mostrar este atributo desde una clase externa
        return self.__rut

#ejemplo de acceso al atributo rut autor desde una clase externa:
# crear objeto autor
#autor1 = Autor('Catalina Pérez')
#print(autor1.nombre_autor)
#try:
#    print(autor1.__rut) 
#except AttributeError as a:
#    print(a) 
#autor1.rut_privado()
#print(autor1.obtener_rut_privado())