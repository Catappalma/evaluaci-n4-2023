from MENU.menuu import Menu,Acceso
from CRUD.encrip import decode
from CRUD.crud import *
connection = conex()

#Usuario registrado: Catalina
#Contraseña: asdf

#Proceso de mejora: En el login habrán 3 intentos para poder ingresar al programa, 
#si el usuario ingresó mal su usuario/contraseña no lo dejará ingresar.

total_intentos = 3
intentos_realizados = 0

print( "\nBienvenido a la mejor libreria :)")
while intentos_realizados < total_intentos:
        print("1- Registrarse")
        print("2- Ingresar ")
        print("0- Salir ")
        op = input('Ingrese opción: ')

        if op == '1':
            a = Acceso()
            a.registroUsuarios()
        
        elif op == '2':
            usuario = input('Ingrese su usuario: ')
            password = input('Ingrese su contraseña: ')
            
            acceso = decode(password,buscarContraseña(usuario, connection))
            if acceso == True:
                m = Menu()
                break
            else:
                intentos_realizados += 1
                print(f'Usuario y/o contraseña incorrecta. Intento {intentos_realizados}/{total_intentos}.')
                
        elif op == '0':
            break

        else:
            print('Opción invalida, por favor intente nuevamente.')
            continue
if intentos_realizados == total_intentos:
    print('Alcanzó el límite de intentos. Saliendo del programa...')