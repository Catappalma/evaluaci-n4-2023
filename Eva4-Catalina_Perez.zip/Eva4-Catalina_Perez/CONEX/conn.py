import mysql.connector

def conex():
    try:
        myconn = mysql.connector.connect(host="localhost", 
                                         user="inacap", 
                                         passwd="1234", 
                                         database="libreriaBD")
        return myconn
    except Exception as ex:
        print(ex)
        myconn.rollback()
    