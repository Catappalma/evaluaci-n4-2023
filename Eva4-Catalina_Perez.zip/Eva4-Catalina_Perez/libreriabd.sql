-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 18-12-2023 a las 04:02:32
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `libreriabd`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estanteria`
--

CREATE TABLE `estanteria` (
  `titulo` varchar(255) NOT NULL,
  `nombre_autor` varchar(255) NOT NULL,
  `categoria` varchar(255) NOT NULL,
  `isbn` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `estanteria`
--

INSERT INTO `estanteria` (`titulo`, `nombre_autor`, `categoria`, `isbn`) VALUES
('invisible', 'Eloy Moreno', 'Juvenil', '2925807');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prestamo`
--

CREATE TABLE `prestamo` (
  `titulo_l` varchar(255) NOT NULL,
  `nombre_usuario` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `prestamo`
--

INSERT INTO `prestamo` (`titulo_l`, `nombre_usuario`) VALUES
('El Resplandor', 'Catalina'),
('Invisible', 'Catalina'),
('Beyond The Story', 'Catalina'),
('Holly', 'Catalina'),
('love and hate', 'Catalina'),
('Harry Potter', 'Catalina'),
('Boulevard', 'Catalina'),
('Silence', 'Catalina'),
('Womans', 'Catalina'),
('La bruja blanca', 'Catalina'),
('El Resplandor', 'Catalina'),
('Invisible', 'Catalina'),
('Beyond The Story', 'Catalina'),
('Holly', 'Catalina'),
('love and hate', 'Catalina'),
('Harry Potter', 'Catalina'),
('Boulevard', 'Catalina'),
('Silence', 'Catalina'),
('Womans', 'Catalina'),
('La bruja blanca', 'Catalina');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `username` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fecha` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`username`, `email`, `password`, `fecha`) VALUES
('catalina', 'catalina@gmail.com', '912ec803b2ce49e4a541068d495ab570', '2023-12-17 23:02:47');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
