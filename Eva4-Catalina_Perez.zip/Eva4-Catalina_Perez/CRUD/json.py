import json
from CONEX.conn import conex

#Profe, se lo dejo como comentario aquí en el código:
#Si es que le llegan a aparecer doble los datos de la tabla prestamo en la base de datos, es porque hice la importación del json.

def preparacion_export():
    lista = []
    lista2 = []
    diccionario={}
    connection = conex()

    try:
        cursor = connection.cursor()
        cursor.execute("select titulo_l, nombre_usuario from prestamo")
        result = cursor.fetchall()

        for u in result:
            prestamo = (u[0], u[1])
            lista.append(prestamo)

        for w in lista:
            lista2.append({'Titulo del libro ':w[0], 'Usuario':w[1]})
            diccionario['Datos Prestamo'] = lista2
        print("Exportación correcta.")
        ExportPrestamo("archivo.json",diccionario)  
    except Exception as ex:
        print(ex)
    return lista


def ExportPrestamo(archivo,obj):
    resul={}
    try:
        out_file = open(archivo, "w", encoding="utf-8")
        json.dump(obj, out_file, indent=4)
        out_file.close()
        resul["mensaje"] = "Datos exportados exitosamente!"
    except Exception as ex:
        resul["Error"] = ex

def leerJson():
    ruta = 'archivo.json'
    with open(ruta) as file:
        data = json.load(file)

        for dat in data['Datos Prestamo']:
            print(dat)

def importPrestamoJson():
    lista=[]

    try:
        ruta = 'archivo.json'
        with open(ruta) as file:
            data = json.load(file)

        for x in data['Datos Prestamo']:
            lista.append((x['Titulo del libro '],x['Usuario']))
        sql = "Insert into prestamo (titulo_l, nombre_usuario) values (%s,%s)"
        connection = conex()
        cursor = connection.cursor()
        cursor.executemany(sql, lista)
        connection.commit()    
        filas = cursor.rowcount
        if filas > 0:
            print("Los datos han sido agregados.")
        else: 
            print("No se realizaron cambios.")

    except Exception as ex:
        print(f"Error al insertar Json: {ex}")