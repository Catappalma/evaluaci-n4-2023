from CONEX.conn import conex
from datetime import datetime
import traceback
from CRUD.encrip import encode

def selectAll_libreria(connection): #muestra los libros que hay en la estanteria
    try:
        connection = conex()
        cur = connection.cursor()
        cur.execute("select titulo, isbn, categoria, nombre_autor from estanteria")
        result =  cur.fetchall()
        print("TITULO     ISBN     CATEGORIA       AUTOR")
        for row in result:
            print("{0}    {1:}    {2}    {3}".format(row[0],row[1],row[2],row[3]))
    except Exception as ex:
        connection.rollback()
        print(ex)

def selectOne_libreria(titulo,connection): #permite buscar un libro de la estanteria
    sql = "select titulo, isbn, categoria, nombre_autor from estanteria where titulo = %s"
    try:
        connection = conex()
        cur = connection.cursor()
        cur.execute(sql, (titulo,))
        result =  cur.fetchone()
        if result is not None:
            print("TITULO     ISBN     CATEGORIA       AUTOR")
            print ("{}    {}    {}    {}".format(result[0],result[1],result[2],result[3]))
        else:
            print('No hay datos que mostrar')            
    except Exception as ex:
        print(traceback.print_exc())

def insertarlibro(titulo, isbn, categoria, nombre_autor):
    sql = "insert into estanteria (titulo, isbn, categoria, nombre_autor) values (%s,%s,%s,%s)"
    try:
        connection = conex()
        cursor = connection.cursor()
        cursor.execute(sql,(titulo, isbn, categoria, nombre_autor))
        connection.commit()
        filas = cursor.rowcount
        if filas > 0:
            print("Datos del libro ingresados correctamente")
        else:
            print("no hubo ningún cambio.")
    except:
        print(traceback.print_exc())


def eliminarlibro(titulo, nombre_autor):
    sql = "delete from estanteria where titulo = %s and nombre_autor = %s"
    try:
        connection = conex()
        cursor = connection.cursor()
        cursor.execute(sql, (titulo, nombre_autor))
        connection.commit()
        filas = cursor.rowcount
        if filas > 0:
            print("Registro del libro eliminado exitosamente")
        else:
            print("no se pudo eliminar")  
    except:
        print("Error")


def update_libro(titulo_libro, nuevo_titulo, nueva_categoria, nuevo_autor, connection):
    sql = "update estanteria set titulo=%s, categoria=%s, nombre_autor=%s WHERE titulo = %s"
    try:
        cursor = connection.cursor()
        cursor.execute(sql, (nuevo_titulo, nueva_categoria, nuevo_autor, titulo_libro))
        filas = cursor.rowcount
        connection.commit()
        print(f"Se ha actualizado {filas}")
        return filas
    except Exception as ex:
        print(f"Error: {ex}")

#Se registrarán prestamos de un libro a pesar de que el libro no esté en la estantería.
def insertarPrestamo(titulo_l,nombre_usuario):
    sql = "insert into prestamo (titulo_l, nombre_usuario) values (%s,%s)"
    try:
        connection = conex()
        cursor = connection.cursor()
        cursor.execute(sql,(titulo_l,nombre_usuario))
        connection.commit()
        filas = cursor.rowcount
        if filas > 0:
            print("Datos ingresados OK")
        else:
            print("no hubo cambios")
    except:
        print(traceback.print_exc())

def mostrarPrestamos(conection):
    try:
        cur = conection.cursor()
        cur.execute("select titulo_l, nombre_usuario from prestamo")
        result =  cur.fetchall()
        print( "Titulo libro          Usuario")
        for row in result:
            print ("{}          {}".format(row[0],row[1]))

    except Exception as ex:
        conection.rollback()
        print('Error', ex)

#funciones para el login: 
def registroUsuarios(username, email, password, connection):
    sql = "insert into usuario (username, email, password, fecha) values (%s,%s,%s,%s)"
    try:
        fecha = datetime.now()        
        cursor = connection.cursor()
        cursor.execute(sql,(username, email, password, fecha))
        connection.commit()
        filas = cursor.rowcount
        if filas > 0:
            print("Datos del usuario ingresados correctamente")
        else:
            print("no se ingresaron datos del usuario")
    except:
        print(traceback.print_exc())

def buscarContraseña(usuario, connection):    
    sql = "select password from usuario where username = %s"
    try:
        cursor = connection.cursor()
        cursor.execute(sql, (usuario,))
        resultado = cursor.fetchone()
        return resultado[0]
    except:
        print(traceback.print_exc())